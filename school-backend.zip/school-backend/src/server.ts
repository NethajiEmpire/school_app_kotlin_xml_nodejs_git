import { createApp } from './app';
import { env } from './config/env';
import { logger } from './utils/logger';
import { closeAllTenantPools } from './core/tenantManager';

const app = createApp();

const server = app.listen(env.port, () => {
  logger.info(`School LMS backend listening on port ${env.port} (${env.nodeEnv})`);
  logger.info(`Health check: ${env.baseUrl}/health`);
});

async function shutdown(signal: string) {
  logger.info(`${signal} received. Shutting down gracefully...`);
  server.close(async () => {
    await closeAllTenantPools();
    process.exit(0);
  });
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
